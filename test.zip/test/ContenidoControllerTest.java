import controller.ContenidoController;
import model.Pelicula;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ContenidoControllerTest {

    @Test
    public void testAgregarContenido() {
        ContenidoController controller = new ContenidoController();
        controller.agregarContenido(new Pelicula("Matrix", 1999, "Wachowski"));
        assertEquals(1, controller.listarContenidos().size());
    }
}