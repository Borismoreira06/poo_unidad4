package view;

import controller.ContenidoController;
import model.*;
import java.util.Scanner;

public class ContenidoView {
    private ContenidoController controller;
    private Scanner scanner;

    public ContenidoView(ContenidoController controller) {
        this.controller = controller;
        this.scanner = new Scanner(System.in);
    }

    public void mostrarMenu() {
        System.out.println("1. Agregar película");
        System.out.println("2. Listar contenido");
        System.out.println("3. Guardar y salir");
    }

    public void iniciar() {
        int opcion;
        do {
            mostrarMenu();
            opcion = scanner.nextInt();
            scanner.nextLine();
            switch (opcion) {
                case 1 -> agregarPelicula();
                case 2 -> listarContenidos();
                case 3 -> controller.guardarEnArchivo("contenido.csv");
            }
        } while (opcion != 3);
    }

    private void agregarPelicula() {
        System.out.print("Título: ");
        String titulo = scanner.nextLine();
        System.out.print("Año: ");
        int anio = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Director: ");
        String director = scanner.nextLine();
        controller.agregarContenido(new Pelicula(titulo, anio, director));
    }

    private void listarContenidos() {
        for (ContenidoAudiovisual c : controller.listarContenidos()) {
            System.out.println(c.getTipo() + ": " + c.getTitulo() + " (" + c.getAnio() + ")");
        }
    }
}