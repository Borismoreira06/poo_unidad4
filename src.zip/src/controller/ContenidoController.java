package controller;

import model.*;
import utils.ArchivoManager;
import java.util.*;

public class ContenidoController {
    private List<ContenidoAudiovisual> contenidos;

    public ContenidoController() {
        contenidos = new ArrayList<>();
    }

    public void cargarDesdeArchivo(String ruta) {
        contenidos = ArchivoManager.leerContenido(ruta);
    }

    public void guardarEnArchivo(String ruta) {
        ArchivoManager.escribirContenido(ruta, contenidos);
    }

    public void agregarContenido(ContenidoAudiovisual c) {
        contenidos.add(c);
    }

    public List<ContenidoAudiovisual> listarContenidos() {
        return contenidos;
    }
}