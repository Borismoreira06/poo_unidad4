package utils;

import model.*;
import java.io.*;
import java.util.*;

public class ArchivoManager {
    public static List<ContenidoAudiovisual> leerContenido(String ruta) {
        List<ContenidoAudiovisual> lista = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(ruta))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                String[] partes = linea.split(",");
                if (partes[0].equals("Pelicula")) {
                    lista.add(new Pelicula(partes[1], Integer.parseInt(partes[2]), partes[3]));
                }
            }
        } catch (IOException e) {
            System.out.println("Error leyendo archivo: " + e.getMessage());
        }
        return lista;
    }

    public static void escribirContenido(String ruta, List<ContenidoAudiovisual> contenidos) {
        try (PrintWriter pw = new PrintWriter(new FileWriter(ruta))) {
            for (ContenidoAudiovisual c : contenidos) {
                if (c instanceof Pelicula p) {
                    pw.println("Pelicula," + p.getTitulo() + "," + p.getAnio() + "," + p.getDirector());
                }
            }
        } catch (IOException e) {
            System.out.println("Error escribiendo archivo: " + e.getMessage());
        }
    }
}